//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Game.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_GameTYPE                    129
#define IDB_BITMAP1                     168
#define IDB_BITMAP2                     169
#define IDB_BITMAP3                     170
#define IDB_BITMAP4                     171
#define IDB_BITMAP5                     172
#define IDB_BITMAP6                     173
#define IDB_BITMAP7                     174
#define IDB_BITMAP8                     175
#define IDB_BITMAP9                     176
#define IDB_BITMAP10                    177
#define IDB_BITMAP11                    178
#define IDB_BITMAP12                    179
#define IDB_BITMAP13                    180
#define IDB_BITMAP14                    181
#define IDB_BITMAP15                    182
#define IDB_BITMAP16                    183
#define IDB_BITMAP17                    184
#define IDB_BITMAP18                    185
#define IDB_BITMAP19                    186
#define IDD_NAME                        189
#define IDD_RANKING                     190
#define IDC_EDIT_NAME                   1001
#define IDC_LIST_RANKING                1003
#define IDC_DELETE                      1005
#define IDC_SEARCH                      1007
#define IDC_LIST1                       1009
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_3x3                          32774
#define ID_4x5                          32775
#define ID_6x6                          32776
#define ID_3x4                          32777
#define ID_4x4                          32779
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_RankShow                     32786
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_CHANCE1                      32792
#define ID_TIMEPLUS                     32793

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        193
#define _APS_NEXT_COMMAND_VALUE         32794
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
